document.addEventListener("DOMContentLoaded", async () => {

  const latestContainer = document.getElementById("latest-news");
  const allNewsContainer = document.getElementById("all-news");

  try {
    // 🔥 Завантажуємо ОБИДВА файли
    const res1 = await fetch("data/news.json");
    const res2 = await fetch("data/new-news.json");

    const oldNews = await res1.json();
    const newNews = await res2.json();

    // ✅ Об’єднуємо всі новини
    const allNews = [...oldNews, ...newNews];

    // ✅ Сортуємо за датою (від новіших до старіших)
    allNews.sort((a, b) => new Date(b.date) - new Date(a.date));

    /* ===============================
       🟢 ГОЛОВНА СТОРІНКА
       =============================== */
    if (latestContainer) {
      latestContainer.innerHTML = "";

      // останні 4 новини
      const latestNews = allNews.slice(0, 4);

      latestNews.forEach(a => {
        const div = document.createElement("div");
        div.className = "news-card vertical";

        div.innerHTML = `
          <img src="${a.image}" alt="${a.title}">
          <h3>${a.title}</h3>
          <p class="date">${new Date(a.date).toLocaleDateString("uk-UA")}</p>

          <button class="read-more"
            onclick="location.href='article.html?id=${a.id}'">
            Читати далі →
          </button>
        `;

        latestContainer.appendChild(div);
      });
    }

    /* ===============================
       🟣 СТОРІНКА news.html
       =============================== */
    if (allNewsContainer) {
      allNewsContainer.innerHTML = "";

      allNews.forEach(a => {
        const div = document.createElement("div");
        div.className = "news-card horizontal";

        div.innerHTML = `
          <img src="${a.image}" alt="${a.title}">

          <div class="text-block">
            <h3>${a.title}</h3>
            <p class="date">${new Date(a.date).toLocaleDateString("uk-UA")}</p>
            <p>${a.text.substring(0, 180)}...</p>

            <button class="read-more small-btn"
              onclick="location.href='article.html?id=${a.id}'">
              Читати далі →
            </button>
          </div>
        `;

        allNewsContainer.appendChild(div);
      });
    }

  } catch (e) {
    console.error("❌ Помилка завантаження новин:", e);

    if (latestContainer) latestContainer.textContent = "Не вдалося завантажити новини.";
    if (allNewsContainer) allNewsContainer.textContent = "Не вдалося завантажити новини.";
  }
});






