// js/article.js

document.addEventListener("DOMContentLoaded", async () => {
  const container = document.getElementById("article-container");

  // Отримуємо ID статті з URL
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  if (!id) {
    container.innerHTML = "<p>Статтю не знайдено.</p>";
    return;
  }

  try {
    // Завантажуємо ОБИДВА файли
    const res1 = await fetch("data/news.json");
    const res2 = await fetch("data/new-news.json");

    const oldNews = await res1.json();
    const newNews = await res2.json();

    // Об’єднуємо всі новини
    const allNews = [...oldNews, ...newNews];

    // Шукаємо статтю за стабільним id
    const article = allNews.find(a => String(a.id) === String(id));

    if (!article) {
      container.innerHTML = "<p>Статтю не знайдено.</p>";
      return;
    }

    // Вставляємо HTML
    container.innerHTML = `
      <button class="back-btn" onclick="history.back()">← Повернутися назад</button>

      <article class="news-card">
        <img src="${article.image}" alt="${article.title}">
        <h2>${article.title}</h2>
        <p class="date">${new Date(article.date).toLocaleDateString("uk-UA")}</p>
        <p>${article.text}</p>
      </article>
    `;

  } catch (err) {
    console.error("Помилка:", err);
    container.innerHTML = "<p>Помилка завантаження статті.</p>";
  }
});

